XRebirthSaveEditorC
===================

X Rebirth save editor by Isbeorn ported to C# NET 4

Original version:
http://www.nexusmods.com/xrebirth/mods/163/
